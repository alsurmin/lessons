create procedure getCount()
  BEGIN
    SELECT count(*) from users;
    SELECT  count(*) from books;
  end;

