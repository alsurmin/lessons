create procedure getUser(IN userId int)
  BEGIN
    select * from users where id = userId;
  end;

